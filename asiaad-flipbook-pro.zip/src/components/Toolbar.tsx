import { ChevronLeft, ChevronRight, FileText, LayoutGrid, Maximize2, Share2, ZoomIn, ZoomOut } from 'lucide-react';
import React from 'react';
import { cn } from '../lib/utils';

interface ToolbarProps {
  currentPage: number;
  totalPages: number;
  onPrev: () => void;
  onNext: () => void;
  onToggleSidebar: () => void;
  onUploadNew: () => void;
  isSidebarOpen: boolean;
  onToggleFullscreen: () => void;
  zoom: number;
  onZoomChange: (value: number) => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  currentPage,
  totalPages,
  onPrev,
  onNext,
  onToggleSidebar,
  onUploadNew,
  isSidebarOpen,
  onToggleFullscreen,
  zoom,
  onZoomChange
}) => {
  return (
    <div className="fixed bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-black/40 backdrop-blur-xl px-4 py-2 rounded-full border border-white/20 shadow-2xl z-50 transition-all">
      <button 
        onClick={onToggleSidebar}
        className={cn(
          "p-2 rounded-full transition-colors",
          isSidebarOpen ? "bg-indigo-500 text-white" : "text-white/60 hover:text-white hover:bg-white/10"
        )}
        title="Thumbnails"
      >
        <LayoutGrid size={18} />
      </button>

      <div className="h-4 w-px bg-white/10 mx-1" />

      {/* Zoom Controls */}
      <div className="flex items-center gap-1">
        <button onClick={() => onZoomChange(Math.max(0.5, zoom - 0.1))} className="p-1.5 text-white/40 hover:text-white transition-colors">
          <ZoomOut size={16} />
        </button>
        <div className="text-[10px] font-mono text-white/40 w-10 text-center">{Math.round(zoom * 100)}%</div>
        <button onClick={() => onZoomChange(Math.min(2, zoom + 0.1))} className="p-1.5 text-white/40 hover:text-white transition-colors">
          <ZoomIn size={16} />
        </button>
      </div>

      <div className="h-4 w-px bg-white/10 mx-1" />

      <button 
        onClick={onPrev}
        disabled={currentPage === 0}
        className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full disabled:opacity-20 disabled:cursor-not-allowed transition-colors"
      >
        <ChevronLeft size={20} />
      </button>

      <div className="flex items-center gap-2 px-3 min-w-[90px] justify-center border-x border-white/10">
        <span className="text-white font-semibold text-sm">Page {currentPage + 1}</span>
        <span className="text-white/30 text-xs">/</span>
        <span className="text-white/60 text-xs">{totalPages}</span>
      </div>

      <button 
        onClick={onNext}
        disabled={currentPage >= totalPages - 1}
        className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full disabled:opacity-20 disabled:cursor-not-allowed transition-colors"
      >
        <ChevronRight size={20} />
      </button>

      <div className="h-4 w-px bg-white/10 mx-1" />

      <button 
        onClick={onToggleFullscreen}
        className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-colors"
        title="Fullscreen"
      >
        <Maximize2 size={18} />
      </button>

      <button 
        onClick={onUploadNew}
        className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-colors"
        title="Upload New"
      >
        <FileText size={18} />
      </button>
    </div>
  );
};
