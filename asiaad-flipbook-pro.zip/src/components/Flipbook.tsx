import React, { forwardRef, useImperativeHandle } from 'react';
import HTMLFlipBook from 'react-pageflip';

interface FlipbookProps {
  images: string[];
  width: number;
  height: number;
  onPageChange: (page: number) => void;
  startPage?: number;
  flippingTime?: number;
  onFlipStart?: () => void;
  drawShadow?: boolean;
  maxShadowOpacity?: number;
  showPageCorners?: boolean;
}

export interface FlipbookRef {
  pageFlip: () => any;
  flipNext: () => void;
  flipPrev: () => void;
  jumpToPage: (page: number) => void;
}

const Page = forwardRef<HTMLDivElement, { image: string; number: number }>((props, ref) => {
  const isLeftPage = props.number % 2 === 0;
  
  return (
    <div className="bg-black/5 shadow-xl overflow-hidden relative" ref={ref}>
      <img 
        src={props.image} 
        alt={`Page ${props.number}`} 
        className="w-full h-full object-contain pointer-events-none"
        onDragStart={(e) => e.preventDefault()}
      />
      {/* Spine Shadow Depth Effect */}
      <div 
        className={`absolute top-0 bottom-0 w-16 pointer-events-none transition-opacity duration-300 ${
          isLeftPage 
            ? "right-0 bg-gradient-to-l from-black/80 via-black/20 to-transparent" 
            : "left-0 bg-gradient-to-r from-black/80 via-black/20 to-transparent"
        }`}
        style={{ opacity: 0.5 }}
      />
    </div>
  );
});

Page.displayName = 'Page';

export const Flipbook = forwardRef<FlipbookRef, FlipbookProps>(({ 
  images, 
  width, 
  height, 
  onPageChange, 
  startPage = 0, 
  flippingTime = 600, 
  onFlipStart,
  drawShadow = true,
  maxShadowOpacity = 0.3,
  showPageCorners = false
}, ref) => {
  const flipbookRef = React.useRef<any>(null);

  useImperativeHandle(ref, () => ({
    pageFlip: () => flipbookRef.current.pageFlip(),
    flipNext: () => flipbookRef.current.pageFlip().flipNext(),
    flipPrev: () => flipbookRef.current.pageFlip().flipPrev(),
    jumpToPage: (page: number) => flipbookRef.current.pageFlip().turnToPage(page),
  }));

  const onFlip = (e: any) => {
    onPageChange(e.data);
  };

  const onFlipStateChange = (e: any) => {
    if (e.data === 'flipping' && onFlipStart) {
      onFlipStart();
    }
  }

  return (
    <div className="relative flex justify-center items-center w-full h-full overflow-hidden p-4">
      {/* @ts-ignore */}
      <HTMLFlipBook
        width={width}
        height={height}
        size="stretch"
        minWidth={300}
        maxWidth={1200}
        minHeight={400}
        maxHeight={1600}
        maxShadowOpacity={maxShadowOpacity}
        showCover={true}
        className="shadow-2xl"
        onFlip={onFlip}
        onChangeState={onFlipStateChange}
        ref={flipbookRef}
        usePortrait={false}
        startPage={startPage}
        drawShadow={drawShadow}
        flippingTime={flippingTime}
        useMouseEvents={true}
        swipeDistance={30}
        showPageCorners={showPageCorners}
        disableFlipByClick={false}
        style={{ margin: '0 auto' }}
      >
        {images.map((image, index) => (
          <Page key={index} image={image} number={index + 1} />
        ))}
      </HTMLFlipBook>
    </div>
  );
});

Flipbook.displayName = 'Flipbook';
