/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AnimatePresence, motion } from 'motion/react';
import { Loader2, Music, UploadCloud, X, Play, Pause, Volume2, VolumeX, Image as ImageIcon, Palette, Zap } from 'lucide-react';
import React, { useEffect, useState, useRef } from 'react';
import { Flipbook, FlipbookRef } from './components/Flipbook';
import { Toolbar } from './components/Toolbar';
import { PDFPageImage, pdfToImages } from './lib/pdf-utils';
import { cn } from './lib/utils';

// Default Assets
const FLIP_SOUND = "https://assets.mixkit.co/active_storage/sfx/2391/2391-preview.mp3";
// Using a classical/instrumental track for the default Indian theme
const AMBIENT_MUSIC = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3";

interface CustomConfig {
  bgColor: string;
  bgImage: string;
  musicUrl: string;
  isMusicPlaying: boolean;
  isFlipSoundEnabled: boolean;
  flippingTime: number;
  drawShadow: boolean;
  maxShadowOpacity: number;
  showPageCorners: boolean;
  volume: number;
}

export default function App() {
  const [images, setImages] = useState<PDFPageImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [config, setConfig] = useState<CustomConfig>({
    bgColor: '#0f172a',
    bgImage: '',
    musicUrl: AMBIENT_MUSIC,
    isMusicPlaying: false,
    isFlipSoundEnabled: true,
    flippingTime: 600,
    drawShadow: true,
    maxShadowOpacity: 0.3,
    showPageCorners: false,
    volume: 0.5,
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const bgImageInputRef = useRef<HTMLInputElement>(null);
  const musicInputRef = useRef<HTMLInputElement>(null);
  const flipbookRef = useRef<FlipbookRef>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Handle Music
  useEffect(() => {
    if (config.musicUrl) {
      if (!audioRef.current) {
        audioRef.current = new Audio(config.musicUrl);
        audioRef.current.loop = true;
      } else if (audioRef.current.src !== config.musicUrl) {
        audioRef.current.src = config.musicUrl;
      }
      
      audioRef.current.volume = config.volume;

      if (config.isMusicPlaying) {
        audioRef.current.play().catch(e => console.log("Audio play blocked by browser", e));
      } else {
        audioRef.current.pause();
      }
    } else if (audioRef.current) {
      audioRef.current.pause();
    }
  }, [config.musicUrl, config.isMusicPlaying, config.volume]);

  const playFlipSound = () => {
    if (config.isFlipSoundEnabled) {
      const audio = new Audio(FLIP_SOUND);
      audio.volume = 0.5;
      audio.play().catch(() => {});
    }
  };

  const updateConfig = (updates: Partial<CustomConfig>) => {
    setConfig(prev => ({ ...prev, ...updates }));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || file.type !== 'application/pdf') return;

    setLoading(true);
    try {
      const pageImages = await pdfToImages(file);
      setImages(pageImages);
      setCurrentPage(0);
    } catch (error) {
      console.error('Error processing PDF:', error);
      alert('Failed to process PDF. Please try again with a valid file.');
    } finally {
      setLoading(false);
    }
  };

  const handleBgImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      updateConfig({ bgImage: url });
    }
  };

  const handleMusicUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      updateConfig({ musicUrl: url, isMusicPlaying: true });
    }
  };

  const onPrev = () => flipbookRef.current?.flipPrev();
  const onNext = () => flipbookRef.current?.flipNext();
  const [zoom, setZoom] = useState(1);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  };

  const jumpToPage = (index: number) => {
    flipbookRef.current?.jumpToPage(index);
    setCurrentPage(index);
  };

  return (
    <div 
      className="min-h-screen text-white selection:bg-indigo-500/30 overflow-hidden font-sans flex flex-col transition-colors duration-700"
      style={{ 
        backgroundColor: config.bgColor,
        backgroundImage: config.bgImage ? `url(${config.bgImage})` : 'none',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      {/* Background Mesh Gradients (only show if no bg image) */}
      {!config.bgImage && (
        <div className="fixed inset-0 pointer-events-none">
          <div className="absolute top-[-100px] left-[-100px] w-[500px] h-[500px] bg-indigo-600/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-[-100px] right-[-100px] w-[600px] h-[600px] bg-blue-500/20 rounded-full blur-[120px]" />
        </div>
      )}

      {/* Hidden Inputs */}
      <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="application/pdf" className="hidden" />
      <input type="file" ref={bgImageInputRef} onChange={handleBgImageUpload} accept="image/*" className="hidden" />
      <input type="file" ref={musicInputRef} onChange={handleMusicUpload} accept="audio/*" className="hidden" />

      <AnimatePresence mode="wait">
        {images.length === 0 && !loading ? (
          <motion.div 
            key="upload"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="flex flex-col items-center justify-center flex-1 px-4 z-10"
          >
            <div className="w-full max-w-xl text-center space-y-8">
              <div className="space-y-4">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center justify-center gap-3 mb-6"
                >
                  <div className="w-12 h-12 bg-indigo-500 rounded-xl flex items-center justify-center font-bold text-2xl shadow-xl shadow-indigo-500/20">A</div>
                  <h1 className="text-4xl md:text-5xl tracking-tight">
                    <span className="font-black">ASIAAD</span> <span className="font-light text-indigo-400">FLIPBOOK PRO</span>
                  </h1>
                </motion.div>
                <div className="w-12 h-1 bg-indigo-500/50 mx-auto rounded-full mb-8" />
                <motion.p 
                  className="text-slate-400 text-lg md:text-xl max-w-md mx-auto leading-relaxed"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  Transform your documents into high-performance digital publications.
                </motion.p>
              </div>

              <motion.div 
                className="group relative"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 }}
              >
                <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-3xl blur opacity-20 group-hover:opacity-40 transition duration-1000" />
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="relative w-full flex flex-col items-center gap-6 glass-panel border-white/10 p-12 transition-all hover:bg-white/10 active:scale-[0.99]"
                >
                  <div className="p-5 bg-white/5 rounded-2xl group-hover:scale-110 transition-transform duration-500 border border-white/5">
                    <UploadCloud size={48} className="text-indigo-400" />
                  </div>
                  <div className="space-y-2">
                    <div className="text-2xl font-semibold tracking-tight">Drop your PDF here</div>
                    <div className="text-slate-400 text-sm font-medium">Professional vector output enabled</div>
                  </div>
                </button>
              </motion.div>

              <motion.div 
                className="pt-12 flex justify-center gap-12 text-slate-500"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <div className="text-[10px] uppercase tracking-[0.3em] font-black">60FPS Rendering</div>
                <div className="text-[10px] uppercase tracking-[0.3em] font-black">HD Resolution</div>
                <div className="text-[10px] uppercase tracking-[0.3em] font-black">Web Optimized</div>
              </motion.div>
            </div>
          </motion.div>
        ) : loading ? (
          <motion.div 
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center flex-1 space-y-8 z-10"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-indigo-500/20 blur-2xl rounded-full animate-pulse" />
              <Loader2 className="w-16 h-16 text-indigo-500 animate-spin relative z-10" />
            </div>
            <div className="space-y-3 text-center">
              <h2 className="text-3xl font-bold tracking-tight">Crafting Publication</h2>
              <p className="text-indigo-400/60 text-sm font-medium tracking-widest uppercase">Initializing Canvas Engine</p>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="viewer"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative h-screen flex flex-col z-10"
          >
            {/* Top Navigation */}
            <nav className="h-16 flex items-center justify-between px-6 bg-white/5 border-b border-white/10 backdrop-blur-md z-50">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center font-bold text-lg cursor-pointer" onClick={() => setImages([])}>A</div>
                <span className="text-lg tracking-tight">
                  <span className="font-black italic">ASIAAD</span> <span className="font-normal text-indigo-400">FLIPBOOK PRO</span>
                </span>
                <div className="h-4 w-px bg-white/10 mx-2" />
                <span className="text-sm text-slate-400 truncate max-w-[200px]">Active Document</span>
              </div>
              <div className="flex items-center gap-4">
                <button className="glass-button flex items-center gap-2" onClick={() => updateConfig({ isMusicPlaying: !config.isMusicPlaying })}>
                  {config.isMusicPlaying ? <Volume2 size={16} /> : <VolumeX size={16} />}
                  Audio
                </button>
                <button className="primary-button">Publish & Share</button>
              </div>
            </nav>

            <div className="flex-1 flex overflow-hidden p-6 gap-6 relative">
              {/* Sidebar / Thumbnails */}
              <AnimatePresence>
                {isSidebarOpen && (
                  <motion.aside 
                    initial={{ x: -300, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    exit={{ x: -300, opacity: 0 }}
                    className="w-48 glass-panel border-white/10 z-40 flex flex-col p-4"
                  >
                    <div className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-6 flex justify-between items-center">
                      <span>Pages ({images.length})</span>
                      <button onClick={() => setIsSidebarOpen(false)} className="hover:text-white transition-colors">
                        <X size={14} />
                      </button>
                    </div>
                    <div className="flex-1 overflow-y-auto space-y-6 custom-scrollbar pr-2">
                      {images.map((img, idx) => (
                        <button 
                          key={idx}
                          onClick={() => jumpToPage(idx)}
                          className="w-full group relative block transition-all"
                        >
                          <div className={cn(
                            "relative aspect-[3/4] rounded-md overflow-hidden transition-all duration-300 border-2",
                            currentPage === idx ? "border-indigo-500 shadow-lg shadow-indigo-500/20" : "border-white/5 opacity-50 group-hover:opacity-100"
                          )}>
                            <img src={img.url} alt={`Page ${idx + 1}`} className="w-full h-full object-cover" />
                          </div>
                          <div className={cn("mt-2 text-[10px] text-center font-bold tracking-widest", currentPage === idx ? "text-indigo-400" : "text-slate-500")}>
                            {idx === 0 ? 'COVER' : String(idx + 1).padStart(2, '0')}
                          </div>
                        </button>
                      ))}
                    </div>
                  </motion.aside>
                )}
              </AnimatePresence>

              {/* Main Stage */}
              <main className="flex-1 flex flex-col">
                <div className="flex-1 bg-black/20 rounded-2xl border border-white/5 flex items-center justify-center p-8 relative overflow-hidden backdrop-blur-sm">
                  <div 
                    className="transition-transform duration-300 flex items-center justify-center"
                    style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}
                  >
                    <Flipbook 
                      ref={flipbookRef}
                      images={images.map(i => i.url)} 
                      width={images[0]?.width || 600}
                      height={images[0]?.height || 800}
                      onPageChange={setCurrentPage}
                      startPage={currentPage}
                      flippingTime={config.flippingTime}
                      onFlipStart={playFlipSound}
                      drawShadow={config.drawShadow}
                      maxShadowOpacity={config.maxShadowOpacity}
                      showPageCorners={config.showPageCorners}
                    />
                  </div>

                  <Toolbar 
                    currentPage={currentPage}
                    totalPages={images.length}
                    onPrev={onPrev}
                    onNext={onNext}
                    onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
                    onUploadNew={() => setImages([])}
                    isSidebarOpen={isSidebarOpen}
                    onToggleFullscreen={toggleFullscreen}
                    zoom={zoom}
                    onZoomChange={setZoom}
                  />
                </div>
              </main>

              {/* Right Sidebar: Customization */}
              <aside className="w-72 hidden xl:flex flex-col gap-6">
                <div className="glass-panel p-5">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 mb-6 flex items-center gap-3">
                    <Palette size={14} /> Background
                  </h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-4 gap-2">
                      {['#0f172a', '#1e293b', '#2d1b4e', '#1a2e05'].map(color => (
                        <button 
                          key={color}
                          onClick={() => updateConfig({ bgColor: color, bgImage: '' })}
                          className={cn("aspect-square rounded-lg border-2", config.bgColor === color && !config.bgImage ? "border-indigo-500" : "border-transparent")}
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                    <button 
                      onClick={() => bgImageInputRef.current?.click()}
                      className="w-full flex items-center gap-2 p-3 bg-white/5 rounded-xl border border-white/10 text-xs hover:bg-white/10 transition-colors"
                    >
                      <ImageIcon size={14} /> 
                      {config.bgImage ? 'Change Image' : 'Custom Image'}
                    </button>
                  </div>
                </div>

                <div className="glass-panel p-5">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 mb-6 flex items-center gap-3">
                    <Music size={14} /> Audio & Sounds
                  </h3>
                  <div className="space-y-4">
                    <button 
                      onClick={() => updateConfig({ isFlipSoundEnabled: !config.isFlipSoundEnabled })}
                      className="w-full flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10 text-xs hover:bg-white/10"
                    >
                      <span className="font-bold tracking-wider">PAGE FLIP SOUND</span>
                      <div className={cn("w-10 h-5 rounded-full relative transition-colors p-1", config.isFlipSoundEnabled ? "bg-indigo-500" : "bg-zinc-700")}>
                        <div className={cn("w-3 h-3 bg-white rounded-full transition-all", config.isFlipSoundEnabled ? "translate-x-5" : "translate-x-0")} />
                      </div>
                    </button>

                    <button 
                      onClick={() => updateConfig({ isMusicPlaying: !config.isMusicPlaying })}
                      className="w-full flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10 text-xs hover:bg-white/10"
                    >
                      <span className="font-bold tracking-wider uppercase">Background Music</span>
                      <div className={cn("w-10 h-5 rounded-full relative transition-colors p-1", config.isMusicPlaying ? "bg-indigo-500" : "bg-zinc-700")}>
                        <div className={cn("w-3 h-3 bg-white rounded-full transition-all", config.isMusicPlaying ? "translate-x-5" : "translate-x-0")} />
                      </div>
                    </button>

                    {config.isMusicPlaying && (
                      <div className="p-3 bg-white/5 rounded-xl border border-white/10 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-white/40">Music Volume</span>
                          <span className="text-[10px] font-mono text-indigo-400">{Math.round(config.volume * 100)}%</span>
                        </div>
                        <input 
                          type="range" 
                          min="0" 
                          max="1" 
                          step="0.01" 
                          value={config.volume}
                          onChange={(e) => updateConfig({ volume: parseFloat(e.target.value) })}
                          className="w-full accent-indigo-500 h-1 bg-white/10 rounded-full appearance-none cursor-pointer"
                        />
                      </div>
                    )}

                    <button 
                      onClick={() => musicInputRef.current?.click()}
                      className="w-full flex items-center gap-2 p-3 bg-white/5 rounded-xl border border-white/10 text-[10px] uppercase font-bold tracking-widest hover:bg-white/10 transition-colors text-slate-400"
                    >
                      <Music size={12} /> Custom Track
                    </button>
                  </div>
                </div>

                <div className="glass-panel p-5">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 mb-6 flex items-center gap-3">
                    <Zap size={14} /> Animation & Effects
                  </h3>
                  <div className="space-y-4">
                    <button 
                      onClick={() => updateConfig({ drawShadow: !config.drawShadow })}
                      className="w-full flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10 text-xs hover:bg-white/10"
                    >
                      <span className="font-bold tracking-wider uppercase">Page Shadows</span>
                      <div className={cn("w-10 h-5 rounded-full relative transition-colors p-1", config.drawShadow ? "bg-indigo-500" : "bg-zinc-700")}>
                        <div className={cn("w-3 h-3 bg-white rounded-full transition-all", config.drawShadow ? "translate-x-5" : "translate-x-0")} />
                      </div>
                    </button>

                    {config.drawShadow && (
                      <div className="p-3 bg-white/5 rounded-xl border border-white/10 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-white/40">Shadow Intensity</span>
                          <span className="text-[10px] font-mono text-indigo-400">{Math.round(config.maxShadowOpacity * 100)}%</span>
                        </div>
                        <input 
                          type="range" 
                          min="0.1" 
                          max="1" 
                          step="0.05" 
                          value={config.maxShadowOpacity}
                          onChange={(e) => updateConfig({ maxShadowOpacity: parseFloat(e.target.value) })}
                          className="w-full accent-indigo-500 h-1 bg-white/10 rounded-full appearance-none cursor-pointer"
                        />
                      </div>
                    )}

                    <div className="p-3 bg-white/5 rounded-xl border border-white/10 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-white/40">Flip Speed</span>
                        <span className="text-[10px] font-mono text-indigo-400">{config.flippingTime}ms</span>
                      </div>
                      <input 
                        type="range" 
                        min="200" 
                        max="2000" 
                        step="100" 
                        value={config.flippingTime}
                        onChange={(e) => updateConfig({ flippingTime: parseInt(e.target.value) })}
                        className="w-full accent-indigo-500 h-1 bg-white/10 rounded-full appearance-none cursor-pointer"
                      />
                    </div>

                    <button 
                      onClick={() => updateConfig({ showPageCorners: !config.showPageCorners })}
                      className="w-full flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10 text-xs hover:bg-white/10"
                    >
                      <span className="font-bold tracking-wider uppercase">Page Curl Hint</span>
                      <div className={cn("w-10 h-5 rounded-full relative transition-colors p-1", config.showPageCorners ? "bg-indigo-500" : "bg-zinc-700")}>
                        <div className={cn("w-3 h-3 bg-white rounded-full transition-all", config.showPageCorners ? "translate-x-5" : "translate-x-0")} />
                      </div>
                    </button>
                  </div>
                </div>
              </aside>
            </div>

            {/* Status Bar */}
            <footer className="h-10 bg-white/5 border-t border-white/10 backdrop-blur-md flex items-center px-6 justify-between text-[10px] text-slate-500 font-bold tracking-widest uppercase">
              <div className="flex gap-8">
                <span>Rendering: WEB_GL</span>
                <span>Audio: {config.isMusicPlaying ? 'ACTIVE' : 'IDLE'}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-indigo-400">ASIAAD FLIPBOOK PRO v1.5</span>
              </div>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
